import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../config/api_config.dart';
import '../models/chat_message.dart';
import 'api_client.dart';

/// Real-time chat over Firestore. Replaces the old short-poll REST
/// service: instead of fetch()/send() hitting our own PHP backend, we
/// exchange our existing API bearer token for a Firebase custom token
/// (via [ApiConfig.chatFirebaseToken]) and then talk to Firestore
/// directly — messages arrive instantly via [messages], no more
/// 4-second poll delay and no more silently-dropped sends.
class ChatService {
  static FirebaseFirestore get _db => FirebaseFirestore.instance;

  String? _threadId;
  int? _restaurantId;
  String? _customerName;
  String? _customerEmail;
  String? _restaurantName;
  int? _orderId;
  String? _orderCode;
  int? _deliveryPartnerId;
  bool _signedIn = false;

  /// Must be called once before [messages]/[send] — signs this device in
  /// to Firebase with the role/ownership claims our backend decided are
  /// valid for [restaurantId] (falls back to the general admin thread if
  /// the customer doesn't actually have an order from that restaurant).
  /// [restaurantName] is only used to denormalize onto the thread doc (so
  /// the Chats list can show "Aachi Samayal" instead of a blank title) —
  /// pass it whenever the caller already has it (e.g. from order tracking).
  Future<void> connect({int? restaurantId, String? restaurantName, int? orderId, int? deliveryPartnerId}) async {
    final res = await ApiClient.get(ApiConfig.chatFirebaseToken(restaurantId, orderId, deliveryPartnerId));
    final token = res['token'] as String;
    _threadId = res['thread_id'] as String;
    // The backend's own validated restaurant_id (null if the requested
    // one wasn't legitimate and it fell back to the admin thread) - used
    // again by sendImage() so the upload lands in the exact same
    // threadId folder as this thread, not a client-guessed one.
    _restaurantId = res['restaurant_id'] != null ? int.tryParse(res['restaurant_id'].toString()) : null;
    // From the backend (not local app state) so the thread doc always
    // gets a real name/email even if the profile wasn't loaded locally —
    // this is what the admin/manager inbox list displays per thread.
    _customerName = res['customer_name'] as String?;
    _customerEmail = res['customer_email'] as String?;
    _restaurantName = restaurantName;
    _orderId = orderId;
    _orderCode = res['order_code'] as String?;
    _deliveryPartnerId = deliveryPartnerId;

    if (!_signedIn) {
      await FirebaseAuth.instance.signInWithCustomToken(token);
      _signedIn = true;
    }
  }

  DocumentReference<Map<String, dynamic>> get _threadRef {
    if (_threadId == null) {
      throw StateError('ChatService.connect() must be called before use.');
    }
    return _db.collection('chat_threads').doc(_threadId);
  }

  CollectionReference<Map<String, dynamic>> get _messagesRef => _threadRef.collection('messages');

  /// Live stream of the thread's messages, oldest first.
  Stream<List<ChatMessage>> messages() {
    return _messagesRef
        .orderBy('createdAt', descending: false)
        .snapshots()
        .map((snap) => snap.docs.map(ChatMessage.fromFirestore).toList());
  }

  /// Live stream of just the thread's status ('open' | 'closed', or null
  /// if no conversation has started yet — treat that as open/new).
  Stream<String?> status() {
    return _threadRef.snapshots().map((snap) {
      if (!snap.exists) return null;
      return (snap.data()?['status'] as String?) ?? 'open';
    });
  }

  /// Live stream of the whole thread doc — used by the Chats list screen
  /// to show a last-message preview + unread badge without opening the
  /// conversation. Returns null if no conversation has started yet.
  Stream<Map<String, dynamic>?> threadData() {
    return _threadRef.snapshots().map((snap) => snap.exists ? snap.data() : null);
  }

  /// Every chat thread (general support AND every restaurant) this
  /// signed-in customer has ever started, newest first — this is what
  /// powers the Chats list, so a restaurant thread shows up there the
  /// first time the customer sends it a message, with no extra step.
  /// Requires being signed in already (any prior connect() call, on any
  /// thread, is enough — the Firebase Auth session is shared app-wide).
  static Stream<List<Map<String, dynamic>>> myThreads() {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return const Stream.empty();
    return _db
        .collection('chat_threads')
        .where('userId', isEqualTo: int.parse(uid))
        .orderBy('lastMessageAt', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map((d) => {...d.data(), 'threadId': d.id}).toList());
  }

  Future<void> send(String text) async {
    final threadSnap = await _threadRef.get();

    // Create/update the thread doc BEFORE adding the message (not after)
    // — a customer's very first message must not leave a message sitting
    // under a thread doc that doesn't exist yet, even briefly.
    if (threadSnap.exists) {
      final wasClosed = (threadSnap.data()?['status'] as String?) == 'closed';
      await _threadRef.update({
        'lastMessage': text,
        'lastMessageAt': FieldValue.serverTimestamp(),
        if (_threadId!.startsWith('delivery_order_')) 'unreadForDelivery': FieldValue.increment(1),
        if (!_threadId!.startsWith('delivery_order_')) 'unreadForStaff': FieldValue.increment(1),
        'unreadForCustomer': 0,
        // Sending a message after the chat ended naturally re-opens it —
        // no separate "reopen" step needed for the customer side.
        if (wasClosed) 'status': 'open',
        if (wasClosed) 'closedAt': null,
        if (wasClosed) 'closedBy': null,
      });
    } else {
      // First message in this thread — create it. userId/restaurantId/
      // recipientRole here must match what the backend's custom-token
      // claims allow, which firestore.rules re-checks on write.
      final parts = _threadId!.split('_');
      final isRestaurant = _threadId!.startsWith('restaurant_') || _threadId!.startsWith('order_');
      final isDelivery = _threadId!.startsWith('delivery_order_');
      await _threadRef.set({
        'userId': int.parse(FirebaseAuth.instance.currentUser!.uid),
        'restaurantId': isRestaurant && !isDelivery ? _restaurantId : null,
        'recipientRole': isDelivery ? 'delivery' : (isRestaurant ? 'manager' : 'admin'),
        'customerName': _customerName,
        'customerEmail': _customerEmail,
        if (isRestaurant && !isDelivery) 'restaurantName': _restaurantName,
        if (isDelivery) 'deliveryPartnerId': _deliveryPartnerId,
        'orderId': _orderId,
        'orderCode': _orderCode,
        'lastMessage': text,
        'lastMessageAt': FieldValue.serverTimestamp(),
        'unreadForStaff': isDelivery ? 0 : 1,
        'unreadForDelivery': isDelivery ? 1 : 0,
        'unreadForCustomer': 0,
        'status': 'open',
      });
    }

    await _messagesRef.add({
      'sender': 'customer',
      'message': text,
      'type': 'text',
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  /// Uploads [imageFile] to our own server (not Firebase Storage — see
  /// Api\ChatApiController::uploadImage) and posts the returned URL as an
  /// image message. Thread creation/update follows the same shape as
  /// [send].
  Future<void> sendImage(File imageFile) async {
    final uploadRes = await ApiClient.postMultipart(
      ApiConfig.chatUploadImage,
      {if (_restaurantId != null) 'restaurant_id': _restaurantId},
      files: {'image': imageFile},
    );
    final imageUrl = uploadRes['url'] as String;

    final threadSnap = await _threadRef.get();

    const captionText = '📷 Photo';

    if (threadSnap.exists) {
      final wasClosed = (threadSnap.data()?['status'] as String?) == 'closed';
      await _threadRef.update({
        'lastMessage': captionText,
        'lastMessageAt': FieldValue.serverTimestamp(),
        if (_threadId!.startsWith('delivery_order_')) 'unreadForDelivery': FieldValue.increment(1),
        if (!_threadId!.startsWith('delivery_order_')) 'unreadForStaff': FieldValue.increment(1),
        'unreadForCustomer': 0,
        if (wasClosed) 'status': 'open',
        if (wasClosed) 'closedAt': null,
        if (wasClosed) 'closedBy': null,
      });
    } else {
      final parts = _threadId!.split('_');
      final isRestaurant = _threadId!.startsWith('restaurant_') || _threadId!.startsWith('order_');
      final isDelivery = _threadId!.startsWith('delivery_order_');
      await _threadRef.set({
        'userId': int.parse(FirebaseAuth.instance.currentUser!.uid),
        'restaurantId': isRestaurant && !isDelivery ? _restaurantId : null,
        'recipientRole': isDelivery ? 'delivery' : (isRestaurant ? 'manager' : 'admin'),
        'customerName': _customerName,
        'customerEmail': _customerEmail,
        if (isRestaurant && !isDelivery) 'restaurantName': _restaurantName,
        if (isDelivery) 'deliveryPartnerId': _deliveryPartnerId,
        'orderId': _orderId,
        'orderCode': _orderCode,
        'lastMessage': captionText,
        'lastMessageAt': FieldValue.serverTimestamp(),
        'unreadForStaff': isDelivery ? 0 : 1,
        'unreadForDelivery': isDelivery ? 1 : 0,
        'unreadForCustomer': 0,
        'status': 'open',
      });
    }

    await _messagesRef.add({
      'sender': 'customer',
      'message': captionText,
      'type': 'image',
      'imageUrl': imageUrl,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  /// Customer taps "End chat". Staff can still see the history; the
  /// customer sending another message re-opens it automatically (see
  /// [send]) rather than needing a separate "reopen" action.
  Future<void> closeChat() async {
    final snap = await _threadRef.get();
    if (!snap.exists) return;
    await _threadRef.update({
      'status': 'closed',
      'closedAt': FieldValue.serverTimestamp(),
      'closedBy': 'customer',
    });
  }

  /// Call when the thread is opened/visible to clear the customer's
  /// unread badge.
  Future<void> markRead() async {
    final snap = await _threadRef.get();
    if (snap.exists) {
      await _threadRef.update({'unreadForCustomer': 0});
    }
  }

  /// Swipe-to-delete on the Chats list — permanently removes the thread
  /// AND every message in it (not just the thread doc), so re-opening the
  /// same restaurant/support thread later starts a clean slate instead of
  /// the old messages reappearing under the same deterministic threadId.
  static Future<void> deleteThread(String threadId) async {
    final ref = _db.collection('chat_threads').doc(threadId);
    final messages = await ref.collection('messages').get();

    // Firestore batches cap at 500 writes; chunk defensively in case a
    // long-running conversation ever has more messages than that.
    const chunkSize = 400;
    for (var i = 0; i < messages.docs.length; i += chunkSize) {
      final batch = _db.batch();
      for (final doc in messages.docs.skip(i).take(chunkSize)) {
        batch.delete(doc.reference);
      }
      await batch.commit();
    }

    await ref.delete();
  }
}
