import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../services/cart_service.dart';
import '../../models/cart_item.dart';
import '../../state/app_state.dart';
import '../../theme.dart';
import '../../widgets/quantity_stepper.dart';
import '../checkout/checkout_screen.dart';
import '../../l10n/app_localizations.dart';

class CartScreen extends StatefulWidget {
  const CartScreen({super.key});
  @override State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  late Future<CartSnapshot> _future;
  final Set<int> _busy = {};

  @override void initState() { super.initState(); _load(); }
  void _load() { _future = CartService.view(); }

  Future<void> _qty(CartItem item, int d) async {
    final q = item.quantity + d;
    if (q < 1) return;
    setState(() => _busy.add(item.id));
    try {
      await CartService.updateQuantity(cartItemId: item.id, quantity: q);
      if (!mounted) return;
      setState(_load);
      context.read<AppState>().refreshCartCount();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(AppLocalizations.of(context)!.errorLabel(e.toString()))),
        );
      }
    } finally {
      if (mounted) setState(() => _busy.remove(item.id));
    }
  }

  double _fee(double s) => s >= 199 ? 0 : 30;

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;
    return Scaffold(
      backgroundColor: AppTheme.scaffoldBg(context),
      appBar: AppBar(
        title: Text(t.myCart, style: const TextStyle(fontWeight: FontWeight.w900)),
        backgroundColor: Colors.transparent,
      ),
      body: FutureBuilder<CartSnapshot>(
        future: _future,
        builder: (c, s) {
          if (s.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          if (s.hasError) return Center(child: Text(t.errorLabel(s.error.toString())));
          final cart = s.data!;
          if (cart.items.isEmpty) return const _EmptyCart();
          final fee = _fee(cart.subtotal);
          final total = cart.subtotal + fee;

          return Column(
            children: [
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(18, 8, 18, 20),
                  children: [
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: AppTheme.surface(context),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 44, height: 44,
                            decoration: BoxDecoration(
                              color: AppTheme.primary.withOpacity(.1),
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(Icons.shopping_bag_rounded, color: AppTheme.primary),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('${cart.items.length} items in your bag', style: const TextStyle(fontWeight: FontWeight.w800)),
                                const SizedBox(height: 3),
                                Text('Review your items before checkout', style: TextStyle(color: AppTheme.textSecondary(context), fontSize: 12)),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 14),
                    ...cart.items.map((item) => Container(
                      margin: const EdgeInsets.only(bottom: 12),
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: AppTheme.surface(context),
                        borderRadius: BorderRadius.circular(18),
                        boxShadow: [BoxShadow(color: Colors.black.withOpacity(.035), blurRadius: 12, offset: const Offset(0, 5))],
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 62, height: 62,
                            decoration: BoxDecoration(
                              color: item.isVeg ? Colors.green.withOpacity(.08) : AppTheme.primary.withOpacity(.08),
                              borderRadius: BorderRadius.circular(15),
                            ),
                            child: Icon(item.isVeg ? Icons.eco_rounded : Icons.restaurant_rounded, color: item.isVeg ? Colors.green : AppTheme.primary, size: 28),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(item.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                                const SizedBox(height: 5),
                                Text('₹${item.price.toStringAsFixed(0)}', style: TextStyle(color: AppTheme.textSecondary(context))),
                              ],
                            ),
                          ),
                          _busy.contains(item.id)
                              ? const SizedBox(width: 28, height: 28, child: CircularProgressIndicator(strokeWidth: 2))
                              : QuantityStepper(quantity: item.quantity, onIncrease: () => _qty(item, 1), onDecrease: () => _qty(item, -1)),
                        ],
                      ),
                    )),
                    Container(
                      padding: const EdgeInsets.all(18),
                      decoration: BoxDecoration(color: AppTheme.surface(context), borderRadius: BorderRadius.circular(20)),
                      child: Column(
                        children: [
                          _row(t.subtotal, cart.subtotal),
                          const SizedBox(height: 10),
                          _row(t.deliveryFee, fee),
                          if (fee == 0)
                            Align(alignment: Alignment.centerLeft, child: Padding(padding: const EdgeInsets.only(top: 4), child: Text(t.freeDeliveryAbove199, style: const TextStyle(color: Colors.green, fontWeight: FontWeight.w700, fontSize: 12))),),
                          const Padding(padding: EdgeInsets.symmetric(vertical: 14), child: Divider()),
                          _row(t.total, total, bold: true),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              SafeArea(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(18, 8, 18, 16),
                  child: SizedBox(
                    width: double.infinity, height: 56,
                    child: ElevatedButton(
                      onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => CheckoutScreen(subtotal: cart.subtotal))).then((_) { if (mounted) setState(_load); }),
                      style: ElevatedButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
                      child: Text(t.proceedToCheckout(total.toStringAsFixed(0)), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15)),
                    ),
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _row(String l, double v, {bool bold = false}) => Row(
    mainAxisAlignment: MainAxisAlignment.spaceBetween,
    children: [
      Text(l, style: TextStyle(fontWeight: bold ? FontWeight.w900 : FontWeight.w500, fontSize: bold ? 17 : 14)),
      Text('₹${v.toStringAsFixed(0)}', style: TextStyle(fontWeight: bold ? FontWeight.w900 : FontWeight.w600, fontSize: bold ? 18 : 14)),
    ],
  );
}

class _EmptyCart extends StatelessWidget {
  const _EmptyCart();
  @override Widget build(BuildContext c) => Center(
    child: Padding(
      padding: const EdgeInsets.all(30),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(width: 96, height: 96, decoration: BoxDecoration(color: AppTheme.primary.withOpacity(.08), shape: BoxShape.circle), child: const Icon(Icons.shopping_bag_outlined, size: 48, color: AppTheme.primary)),
          const SizedBox(height: 20),
          const Text('Your cart is empty', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          Text('Add your favourite food and come back here.', textAlign: TextAlign.center, style: TextStyle(color: AppTheme.textSecondary(c))),
        ],
      ),
    ),
  );
}
